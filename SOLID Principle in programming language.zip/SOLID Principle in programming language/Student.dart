class Student {
  final String name;
  final String studentId;
  final List<Grade> grades = [];

  Student(this.name, this.studentId);

  void addGrade(Grade grade) {
    grades.add(grade);
  }
}

class Course {
  final String name;
  final int credits;

  Course(this.name, this.credits);
}

class Grade {
  final double value;
  final String letter;

  Grade(this.value, this.letter);
}

class GradeBook {
  final List<Student> students = [];
  final List<Course> courses = [];

  void addStudent(Student student) {
    students.add(student);
  }

  void addCourse(Course course) {
    courses.add(course);
  }
}
