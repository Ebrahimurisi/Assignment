import 'Student.dart';

void main() {
  Student student1 = Student("Ebrahim", "20221011111");
  GradeBook gradeBook = GradeBook();
  gradeBook.addStudent(student1);

  Course course1 = Course("Mobile App", 3);
  gradeBook.addCourse(course1);
  student1.addGrade(Grade(90, "A"));

  // طباعة المخرجات
  print("Student name: ${student1.name}");
  print("StudentID: ${student1.studentId}");
  print("Subject: ${course1.name}");
  print("Grade: ${student1.grades.first.value}");
}